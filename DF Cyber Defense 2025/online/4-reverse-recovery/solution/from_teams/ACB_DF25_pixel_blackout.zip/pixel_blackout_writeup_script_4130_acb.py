import base64
from Crypto.Cipher import AES
from typing import Union
import hashlib
import zipfile


#Bước 1: nhận diện C2
#com.example.pixelblackout.nativebridge.D
encrypt_str = "S1dXU1AZDAxRQlQNREpXS1ZBVlBGUUBMTVdGTVcNQExODEBGTVdRQk9ARkZTT1ZQU09WUAxUQk9PU0JTRlFQDE5CUFdGUQxXRlBXDVNNRA=="

#com.example.pixelblackout.x1 => giải mã base64 và thực hiện repeating xor với 0x23
def x1_decode(enc_str) :
    raw = base64.b64decode(enc_str)
    xored = bytes([b ^ 0x23 for b in raw])
    return xored.decode("utf-8", errors="replace")

c2_url = x1_decode(encrypt_str)
print("C2: %s" % c2_url)
#https://raw.githubusercontent.com/centralceeplusplus/wallpapers/master/test.png

#Từ commit có được các file:
#https://github.com/centralceeplusplus/wallpapers/blob/3d339ce5fe9459fdf9c69254620333e34c1ed7e4/data -> base64 decrypt ra được Credential 
#Các file mã hóa từ C2 gửi lên
#https://github.com/centralceeplusplus/wallpapers/blob/8c2a1cec0acc0ba740ef49a59ba199baea633fb5/bundle.bin.enc
#https://github.com/centralceeplusplus/wallpapers/blob/8c2a1cec0acc0ba740ef49a59ba199baea633fb5/sync.dat.enc
#https://github.com/centralceeplusplus/wallpapers/blob/8c2a1cec0acc0ba740ef49a59ba199baea633fb5/profile.dat.enc
#https://github.com/centralceeplusplus/wallpapers/blob/71ba6bc3dd108fd16a210a6ee8083550ca1f05c9/test.png

#Bước 2: phục hồi các file đã mã hóa
#Dựa vào thông tin sync.dat và profile.dat ta biết được dữ liệu được mã hóa với hàm NativeEncryptString
#Từ file https://github.com/centralceeplusplus/wallpapers/blob/71ba6bc3dd108fd16a210a6ee8083550ca1f05c9/test.png, dùng strings tìm được "k","i","p" :)
#Chức năng sẽ nhận key và iv từ server, Trong đó key và iv sau khi giải mã base64 sẽ được repeating xor với 0x37, sau đó dùng AES_CBC PKCS5 để thực hiện mã hóa.
def decode_val(token: str, key: int = 0x37) -> str:
    data = base64.b64decode(token)
    out = bytes(b ^ key for b in data)
    return out.decode('utf-8', 'replace')

from_c2_json = {"k":"BnYGTWcGUmcCZnBSUV4Fc3pnY1FjewJke1pBAHNeQVE=","i":"BwYFBAMCAQAPDlZVVFNSUQ==","p":"ZARUQkUEGnJPUV5bFgUHBQI="}

key = decode_val(from_c2_json["k"])
iv = decode_val(from_c2_json["i"])
password = decode_val(from_c2_json["p"])

print("Key: %s" % key)
print("IV: %s" % iv)
print("Password: %s" % password)

#Ta đã có được Key và IV và cơ chế mã hóa tại chức năng com.example.pixelblackout.nativebridge.NativeCrypto.nativeEncryptString , thực hiện giải mã với AES_CBC PKCS5
BLOCK = 16

def pkcs5_unpad(data: bytes) -> bytes:
    if not data:
        raise ValueError("Empty data")
    pad = data[-1]
    if pad < 1 or pad > BLOCK or data[-pad:] != bytes([pad]) * pad:
        raise ValueError("Invalid PKCS5 padding")
    return data[:-pad]

def decrypt_aes_cbc_pkcs5(ciphertext: Union[str, bytes],
                          key: Union[str, bytes],
                          iv: Union[str, bytes]) -> bytes:

    ct = ciphertext if isinstance(ciphertext, bytes) else ciphertext.encode()
    k = key if isinstance(key, bytes) else key.encode()
    v = iv if isinstance(iv, bytes) else iv.encode()

    cipher = AES.new(k, AES.MODE_CBC, iv=v)
    pt = cipher.decrypt(ct)
    return pkcs5_unpad(pt)

print("="*30)
print("Trying recover sync.dat.enc - profile.dat.enc")

profile_enc = open("evidence/profile.dat.enc","r").readlines()
sync_enc = open("evidence/sync.dat.enc","r").readlines()

for line in profile_enc:
    cipher_line = base64.b64decode(line.strip())
    print("profile.dat recovered: %s" %(decrypt_aes_cbc_pkcs5(cipher_line,key,iv)))

for line in sync_enc:
    cipher_line = base64.b64decode(line.strip())
    print("sync.dat recovered: %s" %(decrypt_aes_cbc_pkcs5(cipher_line,key,iv)))
#Flag part 1: DF25{android_malware_case_is_just_beginning 
#Flag part 2: _and_this_is_second_

#Bước 3: giải mã file bundile.bin.enc, cơ chế đây là 1 zip file bao gồm thông tin các file tại các thư mục như pkg, download, sau đó được mã hóa NativeArchiveEncrypt , nhưng hàm nay phải phân tích trong lib mới biết được cách mã hóa.
#Có 1 lưu ý là hàm này sử dụng nativeConfigure(0x37, key, iv, password) qua com.example.pixelblackout.nativebridge.NativeCrypto.D666()
#Reverse file lib\arm64-v8a\libnative-lib.so , reverse hàm JNI_Onload ta tìm được nguyên tắc tạo key là sử dụng thuật toán AES với Key và IV được tạo từ password.
#Cipher.init(a2, keySpec, ivSpec)
#keySpec = MD5(password)
#ivSpec = SHA256(password)[:16]
#Mã hóa với: AES_CBC PKCS5 (v11 = (*(__int64 (__fastcall **)(__int64, const char *))(*(_QWORD *)a1 + 1336LL))(a1, "AES/CBC/PKCS5Padding");)

def is_zipfile_magic(path: str) -> bool:
    # Kiểm tra magic bytes ZIP
    # PK\x03\x04 (file thường), PK\x05\x06 (empty), PK\x07\x08 (spanned)
    sigs = (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")
    try:
        with open(path, "rb") as f:
            head = f.read(4)
        return head in sigs
    except OSError:
        return False

def derive_aes_params(password: Union[str, bytes]):
    k = password if isinstance(password, bytes) else password.encode('utf-8')
    aes_key = hashlib.md5(k).digest()                  # 16 bytes
    iv = hashlib.sha256(k).digest()[:16]               # 16 bytes
    return aes_key, iv

bundle_bin_enc = open("evidence/bundle.bin.enc","rb").read()

aes_key ,aes_iv = derive_aes_params(password)
print("="*30)
print("Trying to recover bundle.bin file.....")
print("New Key: %s" % aes_key.hex())
print("New IV: %s" % aes_iv.hex())

bundle_bin_recover_data = decrypt_aes_cbc_pkcs5(bundle_bin_enc,aes_key,aes_iv)

recover_bundle_filename = "evidence/bundle.bin.recover.zip"
recovered_bundle_file = open(recover_bundle_filename,"wb").write(bundle_bin_recover_data)

if is_zipfile_magic(recover_bundle_filename):
    print("Recover successfully. File located at: %s" % recover_bundle_filename)
else:
    print("Fail to recover file.")

#Tìm được file ảnh tại downloads/flag.png : turn_down_the_c2_and_we_have_the_flag}

#Final flag: DF25{android_malware_case_is_just_beginning_and_this_is_second_turn_down_the_c2_and_we_have_the_flag}